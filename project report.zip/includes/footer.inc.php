<div id="footer-wrap">
	<p id="legal">MADE BY SHUBH AGARWAL AND SHUBH SINGH</p>
</div>
