<div id="footer-wrap">
	<p id="legal">(c) 2020 Online Book Store.</p>
	</div>